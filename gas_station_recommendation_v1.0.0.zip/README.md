# Gas Station Recommendation - Standalone Package

## 🚀 Quick Start

### Windows Users:
1. Double-click `launch_gas_app.bat`
2. The app will automatically open in your browser
3. If packages are missing, they will be installed automatically

### Mac/Linux Users:
1. Open terminal in this directory
2. Run: `./launch_gas_app.sh`
3. Or run: `python3 launch_gas_app.py`
4. The app will automatically open in your browser

## 📋 Requirements

- Python 3.7 or higher
- Internet connection (for Google Maps API and Claude AI)
- Web browser

## 🔧 Configuration

Before using the app, you need to set up your API keys:

1. **Google Maps API Key** (for gas station locations):
   - Get a key from: https://console.cloud.google.com/
   - Set it in the app when prompted

2. **Claude API Key** (for AI recommendations):
   - Get a key from: https://console.anthropic.com/
   - Set it in the app when prompted

## 🌐 Access the App

Once launched, the app will be available at:
- **Local**: http://localhost:8080
- **Network**: http://[your-ip]:8080

## 🛠️ Troubleshooting

### Port Already in Use
If port 8080 is busy, the app will show an error. You can:
1. Close other applications using port 8080
2. Or modify the port in `gas_recommendation_app/web_app.py`

### Missing Dependencies
If you see import errors:
1. Run: `pip install flask requests anthropic geopy`
2. Or use the launcher scripts which handle this automatically

### API Key Issues
If the app doesn't work properly:
1. Check that your API keys are valid
2. Ensure you have sufficient API credits
3. Check your internet connection

## 📁 Files

- `launch_gas_app.py` - Main launcher script
- `launch_gas_app.bat` - Windows launcher
- `launch_gas_app.sh` - Unix launcher
- `gas_recommendation_app/` - App source code
- `README.md` - This file

## 🎯 Features

- 🚗 Find nearby gas stations
- 💰 Compare prices across different fuel grades (87, 89, 91)
- 🤖 AI-powered recommendations
- 📍 Use current location or enter address
- ⏱️ Real-time travel time calculations
- 💡 Cost analysis including travel expenses

## 📞 Support

If you encounter issues:
1. Check the console output for error messages
2. Ensure all requirements are met
3. Verify your API keys are working

---
Version: 1.0.0
