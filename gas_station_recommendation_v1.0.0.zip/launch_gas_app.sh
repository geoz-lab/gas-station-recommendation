#!/bin/bash

echo "============================================================"
echo "🚗 Gas Station Recommendation"
echo "============================================================"
echo

# Check if Python is installed
if ! command -v python3 &> /dev/null; then
    echo "❌ Python 3 is not installed"
    echo "Please install Python 3 from https://python.org"
    exit 1
fi

# Check if required packages are installed
python3 -c "import flask, requests, anthropic, geopy" 2>/dev/null
if [ $? -ne 0 ]; then
    echo "📦 Installing required packages..."
    pip3 install flask requests anthropic geopy
    if [ $? -ne 0 ]; then
        echo "❌ Failed to install packages"
        exit 1
    fi
fi

echo "🚀 Starting Gas Station Recommendation..."
echo "📍 The app will open in your browser at http://localhost:8080"
echo

# Start the launcher script
python3 launch_gas_app.py
